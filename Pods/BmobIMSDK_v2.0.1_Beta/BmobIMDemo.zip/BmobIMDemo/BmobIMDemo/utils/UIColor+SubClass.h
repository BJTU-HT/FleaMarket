//
//  UIColor+SubClass.h
//  BmobIMDemo
//
//  Created by Bmob on 16/1/18.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (SubClass)

+(instancetype)colorWithR:(CGFloat )r g:(CGFloat)g b:(CGFloat)b;


@end
