//
//  BmobIMMessage+SubClass.h
//  BmobIMDemo
//
//  Created by Bmob on 16/3/8.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import <BmobIMSDK/BmobIMSDK.h>

@interface BmobIMMessage (SubClass)

-(instancetype)initWithMessage:(BmobIMMessage *)message;

@end
