//
//  AudioChatView.h
//  BmobIMDemo
//
//  Created by Bmob on 16/3/7.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import "ChatView.h"



@interface AudioChatView : ChatView


-(void)setMessage:(BmobIMMessage *)msg user:(BmobIMUserInfo *)userInfo;

@end
