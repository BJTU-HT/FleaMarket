//
//  TextChatView.h
//  BmobIMDemo
//
//  Created by Bmob on 16/3/2.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import "ChatView.h"

@interface TextChatView : ChatView

@property (strong, nonatomic) UILabel *contentLabel;



@end
