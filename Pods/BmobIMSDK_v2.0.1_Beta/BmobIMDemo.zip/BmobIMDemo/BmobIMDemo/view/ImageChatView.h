//
//  ImageChatView.h
//  BmobIMDemo
//
//  Created by Bmob on 16/3/2.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import "ChatView.h"

@interface ImageChatView : ChatView
@property (strong, nonatomic) UIButton *imageButton;

@end
