//
//  SysMessage.m
//  BmobIMDemo
//
//  Created by Bmob on 16/1/20.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import "SysMessage.h"

@implementation SysMessage

@end
