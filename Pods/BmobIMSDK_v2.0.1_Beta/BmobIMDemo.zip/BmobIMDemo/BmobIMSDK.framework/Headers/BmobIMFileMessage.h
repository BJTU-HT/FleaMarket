//
//  BmobIMFileMessage.h
//  BmobIMSDK
//
//  Created by Bmob on 16/3/4.
//  Copyright © 2016年 bmob. All rights reserved.
//

#import "BmobIMMessage.h"

@interface BmobIMFileMessage : BmobIMMessage

@property (copy, nonatomic) NSString *localPath;

@end
